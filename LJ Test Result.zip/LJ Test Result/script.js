let scores = [];
let maxScore = 100; // Default max score

document.getElementById("calculateStats").addEventListener("click", () => {
    const maxScoreInput = document.getElementById("maxScoreInput");
    const maxScoreValue = parseInt(maxScoreInput.value);
    
    if (!isNaN(maxScoreValue) && maxScoreValue > 0) {
        maxScore = maxScoreValue; // Update the maximum score
        
        const scoreInput = document.getElementById("scoreInput");
        const inputScores = scoreInput.value.split(',').map(score => parseInt(score.trim())).filter(score => !isNaN(score) && score >= 0);

        if (inputScores.length > 0) {
            scores = inputScores; // Update scores with parsed input
            const mean = calculateMean(scores);
            const standardDeviation = calculateStandardDeviation(scores, mean);
            const max = Math.max(...scores);
            const min = Math.min(...scores);
            const meanPercentageScore = ((mean / maxScore) * 100).toFixed(2); // Calculate MPS
            const masteryLevel = determineMasteryLevel(meanPercentageScore); // Determine mastery level based on MPS

            updateScoreList(); // Update the score list display
            document.getElementById("mean").textContent = mean.toFixed(2);
            document.getElementById("max").textContent = max;
            document.getElementById("min").textContent = min;
            document.getElementById("meanPercentage").textContent = meanPercentageScore; // Updated MPS calculation
            document.getElementById("stdDev").textContent = standardDeviation.toFixed(2);
            document.getElementById("masteryLevel").textContent = masteryLevel;
        } else {
            alert("Please enter valid scores.");
        }
    } else {
        alert("Please enter a valid maximum score.");
    }
});

// Reset functionality
document.getElementById("reset").addEventListener("click", () => {
    scores = [];
    maxScore = 100; // Reset maximum score to default
    document.getElementById("maxScoreInput").value = "";
    document.getElementById("scoreInput").value = "";
    updateScoreList();
    document.getElementById("mean").textContent = "0";
    document.getElementById("max").textContent = "0";
    document.getElementById("min").textContent = "0";
    document.getElementById("meanPercentage").textContent = "0";
    document.getElementById("stdDev").textContent = "0";
    document.getElementById("masteryLevel").textContent = "Not calculated";
});

function updateScoreList() {
    const scoreList = document.getElementById("scoreList");
    scoreList.innerHTML = "";
    scores.forEach((score, index) => {
        const li = document.createElement("li");
        li.textContent = `Score ${index + 1}: ${score}`;
        scoreList.appendChild(li);
    });
}

function calculateMean(scores) {
    const total = scores.reduce((a, b) => a + b, 0);
    return total / scores.length;
}

function calculateStandardDeviation(scores, mean) {
    const variance = scores.reduce((acc, score) => acc + Math.pow(score - mean, 2), 0) / scores.length;
    return Math.sqrt(variance);
}

function determineMasteryLevel(mps) {
    if (mps >= 95) {
        return "Mastered (M)";
    } else if (mps >= 86) {
        return "Closely Approximately Mastery (CAM)";
    } else if (mps >= 66) {
        return "Moving Toward Mastery (MTM)";
    } else if (mps >= 35) {
        return "Average Mastery (AM)";
    } else if (mps >= 15) {
        return "Low Mastery (LM)";
    } else if (mps >= 5) {
        return "Very Low Mastery (VLM)";
    } else {
        return "Absolutely No Mastery (ANM)";
    }
}
